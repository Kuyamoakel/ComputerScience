package cards;

import characters.Player;
import characters.Enemy;

public class BuffCard extends Card {
    private int hpBoost;
    private int manaReduction;


    public BuffCard(String name, int manaCost, int hpBoost, int manaReduction) {
        super(name, manaCost);
        this.hpBoost = hpBoost;
        this.manaReduction = manaReduction;
    }

    @Override
    public void play(Player player, Enemy boss) {
        System.out.println("Player " + super.getName() + " MaxHP "  + player.getMaxHp() + " increase to +" + hpBoost);
        player.setMaxHp(hpBoost);
        player.spendMana(super.getManaCost());
    }

    @Override
    public void printDetails() {
        System.out.println("------------ BUFF CARD ------------");
        System.out.println("Card: " + super.getName());
        System.out.println("Mana Cost: " + super.getManaCost());
        System.out.println("HP Boost: " + hpBoost);
        System.out.println("Mana Cost Reduction: " + manaReduction);
        System.out.println("----------------------------------------");
    }

}